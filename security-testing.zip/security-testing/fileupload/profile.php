<?php
// ⚠️ INTENTIONALLY VULNERABLE FILE UPLOAD SCRIPT
// Do NOT use in production. For security learning only.
error_reporting(1);
if(isset($_POST['upload'])){
    
    // ❌ No validation of file type
    // ❌ No check for PHP extension
    // ❌ No size limit
    // ❌ Directly saving user file with user-controlled name
    $upload_dir = "uploads/";
    
    echo $file_name = $_FILES["file"]["name"];
    echo $file_tmp  = $_FILES["file"]["tmp_name"];
//if ($file_name has the extension == "jpeg,png") {
    // ❌ Directly move uploaded file (VULNERABLE)
    if(move_uploaded_file($file_tmp, $upload_dir . $file_name)){
        echo "<h3>File uploaded successfully: $file_name</h3>";
        echo "<p>Open it: <a href='uploads/$file_name'>uploads/$file_name</a></p>";
    }   else {
        echo "<h3>Upload failed!</h3>";
    }

}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Vulnerable File Upload Demo</title>
</head>
<body>
    <h2>Vulnerable File Upload Demo</h2>
    <form action="" method="POST" enctype="multipart/form-data">
        <input type="file" name="file">
        <br><br>
        <input type="submit" name="upload" value="UploadFile">
    </form>
</body>
</html>
