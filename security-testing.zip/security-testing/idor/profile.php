<?php
// Simulated login session
session_start();
$_SESSION['user_id'] = 1; // logged-in user is ID 5

$mysqli = new mysqli("localhost", "root", "", "testdb");

// ❌ Directly using user-controlled input (IDOR)
$userId = $_GET['id'];   

echo $sql = "SELECT id, name, email FROM users WHERE id = $userId";
$result = $mysqli->query($sql);

if ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . "<br>";
    echo "Name: " . $row['name'] . "<br>";
    echo "Email: " . $row['email'] . "<br>";
}
?>
