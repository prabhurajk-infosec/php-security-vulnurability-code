<?php
// Simulated login session
session_start();
$_SESSION['user_id'] = 3; // logged-in user is ID 3

$mysqli = new mysqli("localhost", "root", "", "testdb");

// ❌ Directly using user-controlled input (IDOR)
$userId = $_GET['id']; //passing as query string     
if ($_SESSION['user_id'] == $userId ) {
$sql = "SELECT id, name, email FROM users WHERE id = $userId";
$result = $mysqli->query($sql);

if ($row = $result->fetch_assoc()) {
    echo "ID: " . $row['id'] . "<br>";
    echo "Name: " . $row['name'] . "<br>";
    echo "Email: " . $row['email'] . "<br>";
}
}else { echo "No access to view other's data. Please stop this!"; }
?>
