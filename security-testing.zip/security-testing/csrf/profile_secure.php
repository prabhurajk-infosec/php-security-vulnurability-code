<?php
session_start();

// Generate CSRF token
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>

<!DOCTYPE html>
<html>
<body>

<h2>Update Email (SECURE)</h2>
<?php //echo $_SESSION['csrf_token']; ?>
<form action="change-email-secure.php" method="POST">
    <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
    <input type="email" name="email">
    
    <button type="submit">Update Email</button>
</form>

</body>
</html>
