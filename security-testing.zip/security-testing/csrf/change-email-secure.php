<?php
session_start();

// CSRF validation
if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die("CSRF validation failed");
}
//Action
if (isset($_POST['email'])) {
    //Storage info inside the DATAbase
    file_put_contents("email.txt", $_POST['email']);
    echo "Email securely updated to: " . htmlspecialchars($_POST['email']);
}
?>
