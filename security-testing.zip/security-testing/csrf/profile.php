<!DOCTYPE html>
<html>
<body>

<h2>Update Email (VULNERABLE)</h2>
<form action="change-email.php" method="POST">
    <input type="email" name="email">
    <button type="submit">Update Email</button>
</form>

</body>
</html>
