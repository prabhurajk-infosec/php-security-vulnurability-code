<?php
session_start();

// ❌ No CSRF validation — vulnerable
if (isset($_POST['email'])) {
    // Example change email logic
    file_put_contents("email.txt", $_POST['email']);
    echo "Email changed to: " . htmlspecialchars($_POST['email']);
}
?>
