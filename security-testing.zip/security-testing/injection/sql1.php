<?php

$conn = mysqli_connect("localhost", "root", "", "testdb");

$username = $_GET['user'];

$sql = "SELECT * FROM users WHERE username = '$username'";

$result = mysqli_query($conn, $sql);

if(!$result){
    echo "The request information is not available";
    //echo mysqli_error($conn); // VULNERABLE: exposing DB errors
}
?>