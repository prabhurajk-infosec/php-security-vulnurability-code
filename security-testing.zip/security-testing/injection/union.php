<?php
// vulnerable.php (INTENTIONALLY VULNERABLE)
$mysqli = new mysqli("localhost", "root", "", "testdb");

$category = $_GET['category']; // user input directly inside SQL

// ❌ Vulnerable to UNION-based SQL injection
echo $sql = "SELECT id, name, price FROM products WHERE category = '?category=electronics' UNION SELECT id, username, password_hash FROM users --
'";

$result = $mysqli->query($sql);

while ($row = $result->fetch_assoc()) {
    echo $row['id'] . " - " . $row['name'] . "<br>";
}
?>
