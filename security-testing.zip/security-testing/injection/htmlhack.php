<!DOCTYPE html>
<html>
<head>
    <title>HTML Injection Demo</title>
</head>
<body>

<h2>Product Feedback</h2>

<form method="GET" action="">
    <input type="text" name="feedback" placeholder="Enter feedback">
    <input type="submit" value="Submit">
</form>

<p>Your feedback:</p>
<p>
    <?php
        // VULNERABLE: displaying user input without escaping
        if (isset($_GET['feedback'])) {
            echo htmlspecialchars($_GET['feedback']);   

        }
    ?>
</p>

</body>
</html>
