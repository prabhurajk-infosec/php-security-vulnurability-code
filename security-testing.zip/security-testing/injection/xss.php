<!DOCTYPE html>
<html>
<head>
    <title>Stored XSS Demo</title>
</head>
<body>
    <h2>Leave a comment</h2>
    <form method="POST" action="">
        <textarea name="comment" rows="4" cols="50"></textarea><br><br>
        <input type="submit" value="Submit">
    </form>

    <?php
    error_reporting(1);
    // Fake storage file
    $file = "comments.txt";

    // Store submitted comment (NO sanitization)
    if(!empty($_POST['comment'])) {
       echo $comment = $_POST['comment'];
        file_put_contents($file, $comment . "\n", FILE_APPEND);
    }

    echo "<h3>Comments:</h3>";

    // Display comments (XSS vulnerable)
    if(file_exists($file)) {
        $comments = file($file);
        foreach($comments as $c) {
            echo "<p>" . $c . "</p>";  // XSS executes here!
        }
    }
    ?>
</body>
</html>
