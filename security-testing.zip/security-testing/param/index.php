<?php
// *** VULNERABLE TO PARAMETER TAMPERING — FOR EDUCATIONAL USE ONLY ***

// Price coming from the client (hidden input) — NEVER TRUST THIS!
$price = $_POST['price'];  
$quantity = $_POST['qty'];

$total = $price * $quantity;

echo "<h2>Order Summary</h2>";
echo "Price per item (user-controlled): ₹" . htmlspecialchars($price) . "<br>";
echo "Quantity: " . htmlspecialchars($quantity) . "<br>";
echo "<strong>Total: ₹" . $total . "</strong>";
?>

<!DOCTYPE html>
<html>
<head><title>Vulnerable Parameter Tampering Demo</title></head>
<body>
    <h3>Buy Product</h3>
    <form method="POST">

        <!-- ❌ Vulnerable: User can edit the price using dev tools -->
        <input type="hidden" name="price" value="1500">

        Quantity: <input type="number" name="qty" value="1"><br><br>

        <button type="submit">Buy Now</button>
    </form>
</body>
</html>
