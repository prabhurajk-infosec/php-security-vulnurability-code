<?php
// call-internal.php
// This script runs on localhost and sends a request to an internal IP (e.g., 192.168.1.50)

// Target internal system URL
$targetUrl = "http://127.0.0.1/internal/app.php";   // change to your internal IP + port

echo "<h3>Requesting: $targetUrl</h3>";

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $targetUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 10,
]);

// Execute
$response = curl_exec($ch);

// Error handling
if ($response === false) {
    echo "cURL Error: " . curl_error($ch);
} else {
    echo "<pre>Response:\n";
    echo htmlspecialchars($response);
    echo "</pre>";
}

curl_close($ch);
?>
